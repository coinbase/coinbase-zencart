<?php

// Coinbase payment plugin
define('MODULE_PAYMENT_COINBASE_TEXT_TITLE', 'Bitcoin (powered by Coinbase)');
define('MODULE_PAYMENT_COINBASE_TEXT_DESCRIPTION', 'Accept Bitcoin with Coinbase.');
define('MODULE_PAYMENT_COINBASE_TEXT_CHECKOUT', 'Bitcoin');